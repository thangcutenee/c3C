var fetch = global.nodemodule["node-fetch"];

var uid = function uid(type, data) {
	(async function () {
		var IDs = [];
		for (var y in data.mentions) {
			IDs.push(y);    
		}
		if(IDs.length != 0){
			var returntext = `Tên của bạn là : ${global.data.cacheName[IDs[0]]}\r\nUID của Bạn Là : ${IDs[0].slice(3,IDs[0].length)}\r\nID Box chat là : ${data.msgdata.threadID}\r\nChúc bạn 1 ngày vui vẻ <3`;
		} else {
				var returntext = ` Tên của bạn là : ${global.data.cacheName["FB-" + data.msgdata.senderID]}\r\nUID của Bạn Là : ${data.msgdata.senderID}\r\nID Box chat là : ${data.msgdata.threadID}\r\nChúc bạn 1 ngày vui vẻ <3 @onii-chan`;
        }
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"UID\" by Diamond";

data.log(onLoadText);

}
module.exports = {
	uid: uid
}