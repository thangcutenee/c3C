// *require stuff*
var PluginName = "autorestart";    // plugin_scope in plugins.js
var config = JSON.parse(global.privateFileMap[PluginName]["config"].toString())["config"];
var plugininfo = JSON.parse(global.privateFileMap[PluginName]["plugininfo"].toString());
var lang = JSON.parse(global.privateFileMap[PluginName]["lang"].toString())["lang"];

// *activate when loading plugin*
function onLoad() {
	check();
	if (global.getType(checkstatus) === "String") {
		console.log(checkstatus);
	}
	auto();
}

var auto = function(){    // will be in onLoad() so no type, data =D
    setTimeout(function(){
	    if (global.getType(checkstatus) === "Boolean") {
		    if(config["toggle"]){
	   		    console.log("\r\n");
    	    	console.log(lang[global.config.language]["Warn"]);
			    console.log(lang[global.config.language]["TimeWarn"].fReplace(config["time"]));
	    	    console.log("\r\n");
    		    setTimeout(function(){
	    		    console.log(lang[global.config.language]["RestartWarn"]);
    	    		process.exit(7378278);
	    	    }, (config["time"]*60)*1000);
	        }
	    } 
    	else {
	    	console.log(checkstatus);
    	}
	}, 5000);
}

// *check config/lang stuff*	
var checkstatus;
var check = function(data){
    function requireFromString(src, filename) {
        var Module = module.constructor;
        var m = new Module();
        m._compile(src, filename);
        return m.exports;
    }
	var path = global.nodemodule["path"];
	var func = requireFromString(global.privateFileMap[PluginName]["checker"].toString(),path.join(__dirname, "checker.js"));
	if(data == undefined || data.resolvedLang == undefined){
	    checkstatus = func.checkreturn(plugininfo, JSON.parse(global.privateFileMap[PluginName]["config"].toString()), JSON.parse(global.privateFileMap[PluginName]["lang"].toString()), global.config.language);
	}
	else {
		checkstatus = func.checkreturn(plugininfo, JSON.parse(global.privateFileMap[PluginName]["config"].toString()), JSON.parse(global.privateFileMap[PluginName]["lang"].toString()), data.resolvedLang);
	}
}

module.exports = {
	onLoad
}