var fs = global.nodemodule["fs"];
var fetch = global.nodemodule["node-fetch"];
var wait = global.nodemodule['wait-for-stuff'];
var path = global.nodemodule["path"];
var streamBuffers = global.nodemodule["stream-buffers"];
var time = new Date();

function onLoad(data) {

    var onLoadText = "loaded fbavt by Kali"
    data.log(onLoadText)
}

function ensureExists(path, mask) {
    if (typeof mask != 'number') {
      mask = 0o777;
    }
    try {
      fs.mkdirSync(path, {
        mode: mask,
        recursive: true
      });
      return undefined;
    } catch (ex) {
      return { err: ex };
    }
  }
    var rootpath = path.resolve(__dirname, "..", "fbavt-data");
ensureExists(rootpath);
ensureExists(path.join(rootpath, "temp"));

function sO(object) {
  return Object.keys(object).length;
}

var fbavatar = async function(type, data) {
    var mentions = data.mentions;
	  var UserAvatar = "UserAvatar_" + Date.now() + ".png";
    if (sO(mentions) == 1) {
        var imgD = "https://graph.facebook.com/" + Object.keys(mentions)[0].slice(3) + "/picture?width=720&height=720&access_token=170440784240186|bc82258eaaf93ee5b9f577a8d401bfc9";
        var fetchimgD = await fetch (imgD);
        var buffer = await fetchimgD.buffer();
        var imagesx = new streamBuffers.ReadableStreamBuffer({
            frequency: 10,
            chunkSize: 1024
        });
        imagesx.path = path.join(rootpath, "temp", UserAvatar);
        imagesx.put(buffer);
        imagesx.stop();
        return {
            handler: "internal",
            data: {
                body: '',
                attachment: ([imagesx])
            }
        }
    }
    if (sO(mentions) == 0) {
      return {
          handler: "internal",
          body: global.config.commandPrefix + "<@mention> [lấy avt fb của ai đó]"
        }
    }
} 

var fbavtid = async function(type, data) {
  var uid = encodeURIComponent(data.args.slice(1).join(" "));
  switch(uid) {
      default: {
          var imgD = "https://graph.facebook.com/" + uid + "/picture?width=720&height=720&access_token=170440784240186|bc82258eaaf93ee5b9f577a8d401bfc9";
          var fetchimgD = await fetch (imgD);
          var buffer = await fetchimgD.buffer();
          var imagesx = new streamBuffers.ReadableStreamBuffer({
              frequency: 10,
              chunkSize: 1024
          });
          imagesx.path = path.join(rootpath, "temp" + Date.now() + ".png");
          imagesx.put(buffer);
          imagesx.stop();
          return {
              handler: "internal",
              data: {
                  body: '',
                  attachment: ([imagesx])
              }
          }
      }
      break;
      case '': {
          return {
              handler: 'internal',
              data: 'vui lòng nhập uid!'
          }
     }
  }  
}

module.exports = {
    fbavatar: fbavatar,
    fbavtid: fbavtid,
    onLoad
}