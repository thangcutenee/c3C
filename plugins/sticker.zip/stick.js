var fs = global.nodemodule["fs"];
var path = global.nodemodule["path"];
var wait = global.nodemodule["wait-for-stuff"];
var streamBuffers = global.nodemodule["stream-buffers"];
var request = global.nodemodule["request"];
var fetch = global.nodemodule["node-fetch"];

function onLoad(data) {

var onLoadText = "Bot đã gửi được sticker ^^";

data.log(onLoadText);
data.log(data);

}

function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}

var rootpath = path.resolve(__dirname, "..", "sticker-folder");
ensureExists(rootpath);
ensureExists(path.join(rootpath, "images"));

var nameMapping = {
	"": path.join(rootpath, "images", ""),
	"": path.join(rootpath, "images", ""),
	"": path.join(rootpath, "images", ""),
	"": path.join(rootpath, "images", "")
}

for (var n in nameMapping) {
	if (!fs.existsSync(nameMapping[n])) {
		fs.writeFileSync(nameMapping[n], global.fileMap[n]);
	}
}

var defaultConfig = {
	 "settings": {
		"enableImages": true
	 },
     "images": {
          "1": {
               "filepath": "1",
               "message": ""
          },
          "2": {
               "filepath": "2",
               "message": ""
          },
          "3": {
               "filepath": "3",
               "message": ""
          },
          "4": {
               "filepath": "4",
               "message": ""
          },
		  "5": {
               "filepath": "5",
               "message": ""
          },
		  "6": {
               "filepath": "6",
               "message": ""
          },
		  "7": {
               "filepath": "7",
               "message": ""
          },
		  "8": {
               "filepath": "8",
               "message": ""
          },
		  "9": {
               "filepath": "9",
               "message": ""
          },
		  "10": {
               "filepath": "10",
               "message": ""
          },
		  "11": {
               "filepath": "11",
               "message": ""
          },
		  "12": {
               "filepath": "12",
               "message": ""
          },
		  "13": {
               "filepath": "13",
               "message": ""
          },
		  "14": {
               "filepath": "14",
               "message": ""
          },
		  "15": {
               "filepath": "15",
               "message": ""
          },
		  "16": {
               "filepath": "16",
               "message": ""
          },
		  "17": {
               "filepath": "17",
               "message": ""
          },
		  "18": {
               "filepath": "18",
               "message": ""
          },
		  "19": {
               "filepath": "19",
               "message": ""
          },
		  "20": {
               "filepath": "20",
               "message": ""
          },
		  "21": {
               "filepath": "21",
               "message": ""
          },
		  "22": {
               "filepath": "22",
               "message": ""
          },
		  "23": {
               "filepath": "23",
               "message": ""
          },
		  "24": {
               "filepath": "24",
               "message": ""
          }
     },
     "message": {
          "noSubCommand": "Hãy dùng lệnh /send sticker",
          "wrongSubCommand": "Lỗi lệnh @@"
	 },
	 "help": {
		 "HELP1": [
			 "Image type must be .jpg",
		 ]
	 }
};

if (!fs.existsSync(path.join(rootpath, "config.json"))) {
	fs.writeFileSync(path.join(rootpath, "config.json"), JSON.stringify(defaultConfig, null, 5));
	var config = defaultConfig;
} else {
	var config = JSON.parse(fs.readFileSync(path.join(rootpath, "config.json"), {
		encoding: "utf8"
	}));
}

var randomFunc = function(type, data) {
var args = data.args;
    args.shift();
		if (!args[0]) return{ handler: 'internal', data: config.message.noSubCommand };
	switch (args[0].toLowerCase()) {
		default:
		return { handler: 'internal', data: config.message.wrongSubCommand };
			break;
		case 'sticker':
		case 'stick':
		case 'sti':
		if (config.settings.enableImages) {
		var random = config.images[Object.keys(config.images)[Math.floor(Math.random()*Object.keys(config.images).length)]];
		var randomImages = fs.createReadStream(path.join(rootpath, "images", random.filepath+".jpg"));
		return data.return({
			handler: `internal-raw`,
			data: {
				body: random.message,
				attachment: randomImages
			}
		})
		} else {
			return data.return({
				handler: "internal",
				data: "This feature is disable"
			})
		}
	}
}
module.exports = {
    random: randomFunc,
    onLoad
};
